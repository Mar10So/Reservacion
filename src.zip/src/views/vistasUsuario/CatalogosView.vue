<template>
    <h1>Hola Soy un menu</h1>
</template>
<script>
/* import axios from 'axios'; */
export default{
    name: 'CatalogosView',
    data(){
        return{

        }
    }
}
</script>