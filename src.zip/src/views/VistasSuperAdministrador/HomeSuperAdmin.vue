<template>
  <h1>Hola Bienvenido SuperAdmin</h1>
  <!-- Aqui  card de restaurantes con sus respectivos administradores -->
  <!-- crear una vista donde se puedan Agregar, Modificar, Eliminar Restaurantes -->
  <!-- crear una vista donde se puedan Agregar, Modificar, Eliminar Administradores  -->
</template>
<script>

export default{
  name: 'HomeSuperAdmin'
}
</script>